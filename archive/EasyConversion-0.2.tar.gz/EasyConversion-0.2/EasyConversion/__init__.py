from EasyConversion.convert import Convert
from EasyConversion.docs import Docs