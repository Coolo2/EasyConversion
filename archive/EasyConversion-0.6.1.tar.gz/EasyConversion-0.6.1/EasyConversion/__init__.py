
import EasyConversion
from EasyConversion import docs