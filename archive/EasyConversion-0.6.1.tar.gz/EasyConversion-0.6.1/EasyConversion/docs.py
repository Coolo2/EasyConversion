from EasyConversion import textformat

colour = textformat.color

class Dec:
    Bin = "https://easyconversion.readthedocs.io/en/master/#decimal-to-binary"

    Letter = "https://easyconversion.readthedocs.io/en/master/#decimal-to-letter"

    letter, let, Let = Letter, Letter, Letter
    bin, binary, Binary = Bin, Bin, Bin



decimal, dec, Decimal = Dec, Dec, Dec

class Bin():
    Dec = "https://easyconversion.readthedocs.io/en/master/#binary-to-decimal"
    dec, decimal, Decimal = Dec, Dec, Dec

binary, Binary, bin = Bin, Bin, Bin

class Letter:
    Decimal = "https://easyconversion.readthedocs.io/en/master/#letter-to-decimal"

    dec, Dec, decimal = Decimal, Decimal, Decimal
                                
letter, let, Let = Letter, Letter, Letter

class String:
    Ascii = "https://easyconversion.readthedocs.io/en/master/#letter-string-to-ascii"
    asc, Asc, asciibinary, AsciiBinary, Asciibinary = Ascii, Ascii, Ascii, Ascii, Ascii
    morse = "https://easyconversion.readthedocs.io/en/master/#string-to-morse"
    Morse, morsecode, Morsecode, MorseCode = morse, morse, morse, morse
letter, string, Letter, Str, let, Let = String, String, String, String, String, String

class Ascii:
    String = "https://easyconversion.readthedocs.io/en/master/#ascii-binary-to-letter-string"
    letter, string, Letter, Str, let, Let = String, String, String, String, String, String
asc, Asc, asciibinary, AsciiBinary, Asciibinary = Ascii, Ascii, Ascii, Ascii, Ascii

class morse:
    String = "https://easyconversion.readthedocs.io/en/master/#morse-to-string"
    letter, string, Letter, Str, let, Let = String, String, String, String, String, String
Morse, morsecode, Morsecode, MorseCode = morse, morse, morse, morse