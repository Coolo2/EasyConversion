
from EasyConversion import convert
from EasyConversion import docs