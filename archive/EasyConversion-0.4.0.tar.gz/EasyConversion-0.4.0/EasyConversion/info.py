class version:
    name = "0.4.0"
    release_date = "28th June 2020"